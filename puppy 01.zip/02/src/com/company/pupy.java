package com.company;

public class pupy {
    public pupy(String name) {
// This constructor has one parameter, name.
        System.out.println("Passed Name is :" + name );
    }
    public static void main(String []args) {
// Following statement would create an object myPuppy
        pupy myPuppy = new pupy( "tommy" );
    }
}



