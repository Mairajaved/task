package com.company;

public class Main {

    public static void main(String[] args) {
        String breed;
        int age;
        String color;

    }

}

