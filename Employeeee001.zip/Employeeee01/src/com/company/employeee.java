package com.company;
import java.io.*;
public class employeee {

        public static void main(String args[]) {
            /* Create two objects using constructor */
            employee empOne = new employee("Furqan");
            employee empTwo = new employee("Huzaifa");
// Invoking methods for each object created
            empOne.empAge(30);
            empOne.empDesignation("Senior Software Engineer");
            empOne.empSalary(2000);
            empOne.printEmployee();
            empTwo.empAge(29);
            empTwo.empDesignation("Software Engineer");
            empTwo.empSalary(1500);
            empTwo.printEmployee();
        }
    }

