package com.company;

public class TASK {
    public class Puppy {
        public Puppy() {
        }
        public Puppy(String name) {
// This constructor has one parameter, name.
        }
    }

}
